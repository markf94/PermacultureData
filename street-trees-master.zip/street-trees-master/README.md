# street-trees
NYC street tree map. ~600,000 trees. Based on 2005 NYC Dept of Parks and Recreation street tree census.<br/>Map will be updated with 2015 census data when available.
